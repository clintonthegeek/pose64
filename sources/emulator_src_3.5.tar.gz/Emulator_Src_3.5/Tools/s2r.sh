#!/bin/sh

perl ../Tools/Strings2Resource.pl ../SrcShared/Strings.txt



