 /*
  * UAE - The Un*x Amiga Emulator
  *
  * memory management
  *
  * Copyright 1995 Bernd Schmidt
  */

#include "machdep_maccess.h"

typedef EmAddressBank	addrbank;

#define get_mem_bank	EmMemGetBank
